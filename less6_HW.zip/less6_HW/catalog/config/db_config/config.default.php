<?php

return [
    'db_user' => 'root',
    'db_pass' => '',
    'db_name' => 'test',
    'db_host' => 'localhost'
];