<?php
const DS = DIRECTORY_SEPARATOR;

function geleryPics ($path) {
    $list = scandir($path);
    unset($list[0], $list[1]);
    
    foreach ($list as $filename) {
    //     echo '<a href="'.$path.DS.$filename.'" target="_blank">'.
    //         '<img class="small-pic" src="'.$path.DS.$filename.'">'.'</a>';

            echo '<a onclick="modalwindow(\''.$filename.'\')">'.
            '<img class="small-pic" src="'.$path.DS.$filename.'">'.'</a>'.PHP_EOL;
    }
    
}
