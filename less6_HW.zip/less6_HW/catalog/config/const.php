<?php

define('ROOT_DIR', __DIR__.'/../');
define('PUBLIC_DIR', __DIR__.'/../public/');
define('ENGINE_DIR', __DIR__.'/../engine/');
define('CONFIG_DIR', ROOT_DIR.'/config'.DIRECTORY_SEPARATOR);