<?php
function summ($val1, $val2) {
    return $val1+$val2;
}