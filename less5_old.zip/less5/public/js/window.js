

function fullScreenWindow (nViews=0, fileName) {

    let newWin = window.open('public/moduls/newWindow.html');

    newWin.onload = function() {

        newWin.document.body.innerHTML = '<img src="../img/'+fileName+'">'+'<p>Число кликов - '+nViews+'</p>'

    }

}
//public/img/img1.jpg